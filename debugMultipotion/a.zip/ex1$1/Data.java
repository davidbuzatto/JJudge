public class Data {
    public int d;
    public String toString() {
        return d + " xyz";
    }
}