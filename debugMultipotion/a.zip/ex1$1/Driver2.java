public class Driver2 {
    public static void main( String[] args ) {
        Data d = new Data();
        d.d = 100;
        System.out.println( d );
    }
}
