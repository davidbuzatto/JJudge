# -*- coding: utf-8 -*-

print( "a a a" )
print( "a a a" )
print( "a\ta\ta\n" )
print( "a\ta\ta\n" )
print( "\ta\ta" )
