# -*- coding: utf-8 -*-

print( "n1: " )
n1 = input()

print( "n2: " )
n2 = input()

r = n1 // n2

print( "output: " + str( r ) )