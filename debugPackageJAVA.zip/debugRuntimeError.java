
public class debugRuntimeError {

    public static void main( String[] args ) {
        f();
    }

    public static void f() {
        f();
    }
    
}
