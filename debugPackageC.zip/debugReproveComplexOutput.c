#include <stdio.h>
#include <stdlib.h>

int main() {

    printf( "a a a\n" );
    printf( "a a a\n" );
    printf( "x\ta\ta\n\n" );
    printf( "a\ta\ta\n\n" );
    printf( "\ta\ta" );

    return 0;

}
