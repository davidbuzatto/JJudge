import java.io.*;
import java.math.*;
import java.util.*;

public class Exercicio1$4 {

    public static void main( String[] args ) {
        
        Scanner scan = new Scanner( System.in );

        System.out.printf( "       *\n" );
        System.out.printf( "      *\n" );
        System.out.printf( "     *\n" );
        System.out.printf( "*   *\n" );
        System.out.printf( " * *\n" );
        System.out.printf( "  *" );

    }

}
