# -*- coding: utf-8 -*-

def f():
    f()

f()
