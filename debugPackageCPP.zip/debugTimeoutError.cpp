#include <iostream>

using namespace std;

void f() {
    int i = 0;
    for (;;) {
        i = 0;
    }
}

int main() {

    f();

    return 0;

}
