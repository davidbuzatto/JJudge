#include <iostream>

using namespace std;

void f() {
    f();
}

int main() {

    f();

    return 0;

}
