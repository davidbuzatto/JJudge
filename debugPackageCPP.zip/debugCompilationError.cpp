#include <iostream>

using namespace std;

int main() {

    int n1;
    int n2
    int r;

    cout << "n1: ";
    cin >> n1;

    cout << "n2: ";
    cin >> n2;

    r = n1 + n2;

    cout << "output: " << r;

    return 0;

}
